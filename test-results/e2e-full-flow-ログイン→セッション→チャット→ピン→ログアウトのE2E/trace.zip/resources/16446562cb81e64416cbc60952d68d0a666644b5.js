(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_f32b63aa._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa2e.js",
  "static/chunks/node_modules_micromark-core-commonmark_dev_lib_36a4b45d._.js",
  "static/chunks/node_modules_refractor_f85e00c5._.js",
  "static/chunks/node_modules_@firebase_5954d29b._.js",
  "static/chunks/node_modules_6a8093cd._.js",
  "static/chunks/_7605fd08._.js"
],
    source: "dynamic"
});
