(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_bf5ee8e7._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa2e.js",
  "static/chunks/node_modules_@dnd-kit_core_dist_core_esm_deb93fb9.js",
  "static/chunks/node_modules_2c4b1df8._.js",
  "static/chunks/_0ee30088._.js"
],
    source: "dynamic"
});
